package com.example.icefishinganalyser

import android.app.Notification
import android.app.NotificationChannel
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private lateinit var summary: TextView
    private lateinit var prediction: TextView
    private val results = mutableListOf<String>()

    // Illustrative 53-segment wheel baseline; verify against the exact table/game version.
    private val names = listOf("Leaf 1", "Leaf 2", "Lil' Blues", "Big Oranges", "Huge Reds")
    private val baseline = listOf(23.0/53.0, 23.0/53.0, 4.0/53.0, 2.0/53.0, 1.0/53.0)

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createPanel()
    }

    private fun startForegroundNotification() {
        val channelId = "ice_fishing_analyser"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Ice Fishing Analyser", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
                      else Notification.Builder(this)
        startForeground(7, builder.setContentTitle("Ice Fishing Analyser")
            .setContentText("Floating result tracker is running")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build())
    }

    private fun createPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.argb(242, 20, 34, 49))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(TextView(this).apply {
            text = "ICE FISHING • PREDICTION ESTIMATE"
            setTextColor(Color.WHITE); textSize = 13f
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Button(this).apply { text = "×"; setOnClickListener { stopSelf() } })
        root.addView(header)

        prediction = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f
            setPadding(0, 10, 0, 8)
        }
        root.addView(prediction)

        summary = TextView(this).apply {
            setTextColor(Color.LTGRAY); textSize = 11f
            setPadding(0, 4, 0, 8)
        }
        root.addView(summary)

        names.forEachIndexed { index, name ->
            root.addView(Button(this).apply {
                text = "Record: $name"
                textSize = 12f
                setOnClickListener { addResult(names[index]) }
            })
        }
        root.addView(Button(this).apply {
            text = "UNDO LAST RESULT"
            setOnClickListener { if (results.isNotEmpty()) { results.removeAt(results.lastIndex); refresh() } }
        })
        root.addView(Button(this).apply {
            text = "RESET HISTORY"
            setOnClickListener { results.clear(); refresh() }
        })
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 140 }
        panel = root
        wm.addView(root, params)
        refresh()
    }

    private fun addResult(name: String) {
        results.add(name)
        while (results.size > 500) results.removeAt(0)
        refresh()
    }

    private fun refresh() {
        val total = results.size
        val counts = names.map { n -> results.count { it == n } }
        val observed = counts.map { if (total == 0) 0.0 else it.toDouble() / total }
        // Transparent descriptive score: 50% wheel baseline + 50% observed history.
        // This is a ranking heuristic, NOT a calibrated forecast of the next independent spin.
        val scores = names.indices.map { i -> 0.5 * baseline[i] + 0.5 * observed[i] }
        val best = scores.indices.maxByOrNull { scores[it] } ?: 0
        val scoreLines = names.indices.joinToString("\n") { i ->
            val pct = scores[i] * 100.0
            "${names[i]}: ${String.format(Locale.US, "%.1f", pct)}% estimate score  |  ${counts[i]}/$total observed"
        }
        val recent = results.takeLast(8).asReversed().joinToString(" • ").ifEmpty { "—" }
        prediction.text = "TOP STATISTICAL PICK: ${names[best]}\nScore: ${String.format(Locale.US, "%.1f", scores[best] * 100)}%"
        summary.text = "Recorded: $total / 500\n$scoreLines\n\nRecent (newest first):\n$recent\n\nEstimate blends wheel proportions and recorded history. It cannot reliably predict a random next spin."
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
