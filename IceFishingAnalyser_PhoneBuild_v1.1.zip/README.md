# Ice Fishing Analyser (Android MVP)

A floating Android result logger for Evolution Ice Fishing. It records the last 50 outcomes and displays observed frequencies.

## Important limitation
This app does **not** read the game automatically and does **not** predict the next outcome. The user taps the matching outcome after each completed round. This avoids falsely recording static labels printed on the wheel as new results. Past frequencies do not establish the next independent result.

## Build
1. Install Android Studio (Giraffe or newer) on a computer.
2. Open this folder as an existing Android Studio project.
3. Allow Gradle sync to download the Android Gradle Plugin and Kotlin plugin.
4. Connect the OnePlus 11R with USB debugging enabled, or build an APK using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the APK on the phone.

## Use
1. Open Ice Fishing Analyser.
2. Tap **Allow display over other apps** and enable the permission.
3. Return to the app and tap **Start floating analyser**.
4. Open the game. Move the floating panel if it covers important game controls.
5. After each round has fully settled, tap the matching outcome in the panel.
6. Use Undo if you selected the wrong outcome.

## Notes
- The app requests overlay permission and runs a foreground service while the panel is visible.
- History is held in memory and resets when the service is stopped or the app process is killed.
- Do not enter bets based on the displayed frequencies. The panel is an observational tracker, not a betting signal.
- This starter project has not been compiled or tested on a physical device. Android Studio/Gradle may request SDK or plugin updates.

## Prediction estimate panel (v1.1)
The overlay now displays a **Top Statistical Pick** and a percentage score. The score is a transparent heuristic blending the wheel's illustrative segment proportions (50%) with the manually recorded history (50%). It is not a calibrated probability and cannot reliably predict an independent random outcome. Verify the wheel layout for the exact game version/table before relying on baseline proportions. The tracker stores up to 500 outcomes in memory; this MVP still does not automatically read the game screen or persist results after the service stops.
