plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.icefishinganalyser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.icefishinganalyser"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.2"
    }

    // Keep Java and Kotlin bytecode targets aligned (fixes the reported JVM 1.8 vs 17 error).
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
